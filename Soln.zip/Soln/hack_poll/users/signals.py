from django.db.models.signals import post_save
from django.contrib.auth.models import User #sender
from django.dispatch import receiver        #receiver
from .models import Profile, Voted


@receiver(post_save, sender=User)
def create_profile(sender, instance, created, **kwargs):
	if created:
		Profile.objects.create(user=instance)
		Voted.objects.create(user=instance)


@receiver(post_save, sender=User)
def save_profile(sender, instance, **kwargs):
	instance.profile.save()
	instance.profile.save()