from django.contrib import admin
from .models import Candidate

admin.site.register(Candidate)
