from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from mainPoll.models import Candidate
from users.models import Voted
from django.contrib import messages


def home(request):
	context = {
		'polls': Candidate.objects.all(),
		'title': 'Home',
	}
	return render(request, 'poll/home.html', context=context)

class PollListView(ListView):
	model = Candidate
	template_name = 'poll/home.html' # default is <app>/<model>_<viewtype>.html
	context_object_name = 'polls'

class PollDetailView(DetailView):
	model = Candidate

class PollUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
	model = Candidate
	fields = ['about_me', 'expertise', 'noOfChallenges']

	def form_valid(self, form):
		form.instance.profile = self.request.user
		return super().form_valid(form)

	def test_func(self):
		candidate = self.get_object()
		return self.request.user == candidate.profile

@login_required
def PollUpdateVote(request, userid, pk):
	voted_res = Voted.objects.filter(user_id=userid).first()
	if voted_res.voted == False:
		candidate = Candidate.objects.filter(id=pk).first()
		candidate.voteTotal += 1
		candidate.save()
		voted_res.voted = True
		voted_res.save()
		messages.success(request, f'You have successfully voted')
		return redirect('poll-home')
	else:
		messages.success(request, f'You have already voted')
		return redirect('poll-home')
