from django.urls import path
from . import views
from .views import PollListView, PollDetailView, PollUpdateView

urlpatterns = [
    path('', PollListView.as_view(), name='poll-home'),
    path('poll/<int:pk>/', PollDetailView.as_view(), name='poll-detail'),
    path('poll/<int:pk>/update/', PollUpdateView.as_view(), name='poll-update'),
    path('poll/<int:userid>/<int:pk>/vote/', views.PollUpdateVote, name='poll-vote'),
]