from django.apps import AppConfig


class MainpollConfig(AppConfig):
    name = 'mainPoll'
