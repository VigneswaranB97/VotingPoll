from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse


class Candidate(models.Model):
	CATAGORY = (
					('I', 'I'),
					('II', 'II'),
					('III', 'III'),
					('IV', 'IV'),
					('V', 'V'),
				)
	
	profile = models.OneToOneField(User, on_delete=models.CASCADE)
	about_me = models.TextField()
	expertise = models.CharField(max_length=200, default='I', choices=CATAGORY)
	noOfChallenges = models.IntegerField() 
	voteTotal = models.IntegerField(default=0)

	def __str__(self):
		return self.profile.username

	def get_absolute_url(self):
		return reverse('poll-detail', kwargs={'pk': self.pk})