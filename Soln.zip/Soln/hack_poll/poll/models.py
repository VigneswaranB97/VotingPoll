from django.db import models
from django.contrib.auth.models import User


class Candidate(models.Model):
	CATAGORY = (
					('I', 'I'),
					('II', 'II'),
					('III', 'III'),
					('IV', 'IV'),
					('V', 'V'),
				)
	
	name = models.CharField(max_length=100)
	about_me = models.TextField()
	expertise = models.CharField(max_length=200, default='I', choices=CATAGORY)
	noOfChallenges = models.IntegerField() 

	def __str__(self):
		return self.name

	
