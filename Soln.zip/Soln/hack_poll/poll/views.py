from django.shortcuts import render
from poll.models import Candidate


def home(request):
	context = {
		'polls': Candidate.objects.all(),
		'title': 'Home',
	}
	return render(request, 'poll/home.html', context=context)